// VLM SHOP — Google Apps Script backend
// 1) Put your Telegram bot token into BOT_TOKEN.
// 2) Put your Telegram numeric user/chat ID into ADMIN_CHAT_ID.
// 3) Deploy as Web app: Execute as Me, Who has access: Anyone.
// 4) Copy the /exec URL and use it as the bot webhook.

const BOT_TOKEN = "PASTE_BOT_TOKEN_HERE";
const ADMIN_CHAT_ID = "PASTE_ADMIN_CHAT_ID_HERE";

function doPost(e) {
  try {
    const update = JSON.parse(e.postData.contents);

    // Orders sent by Telegram Mini App via WebApp.sendData arrive as web_app_data.
    const msg = update.message;
    if (msg && msg.web_app_data && msg.web_app_data.data) {
      const order = JSON.parse(msg.web_app_data.data);
      const user = msg.from || {};
      const text = formatOrder(order, user);

      sendTelegram("sendMessage", {
        chat_id: ADMIN_CHAT_ID,
        text: text,
        parse_mode: "HTML"
      });

      sendTelegram("sendMessage", {
        chat_id: msg.chat.id,
        text: "✅ Заказ принят! Менеджер свяжется с вами."
      });
    }
    return ContentService.createTextOutput("OK");
  } catch (err) {
    console.log(err);
    return ContentService.createTextOutput("ERROR");
  }
}

function formatOrder(order, user) {
  let lines = [];
  lines.push("🛍 <b>НОВЫЙ ЗАКАЗ — VLM SHOP</b>");
  lines.push("");
  lines.push("👤 Имя: " + esc(order.name));
  lines.push("📞 Контакт: " + esc(order.phone));
  if (order.comment) lines.push("📍 Комментарий: " + esc(order.comment));
  if (user.username) lines.push("Telegram: @" + esc(user.username));
  lines.push("");
  lines.push("<b>Товары:</b>");

  let total = 0;
  (order.items || []).forEach((x, i) => {
    const sum = Number(x.price) * Number(x.qty);
    total += sum;
    lines.push((i+1) + ". " + esc(x.product) + " — " + esc(x.variant) + " × " + x.qty + " = " + sum + " zł");
  });
  lines.push("");
  lines.push("💰 <b>Итого: " + total + " zł</b>");
  return lines.join("\n");
}

function esc(s) {
  return String(s || "").replace(/&/g,"&amp;").replace(/</g,"&lt;").replace(/>/g,"&gt;");
}

function sendTelegram(method, payload) {
  const url = "https://api.telegram.org/bot" + BOT_TOKEN + "/" + method;
  UrlFetchApp.fetch(url, {
    method: "post",
    contentType: "application/json",
    payload: JSON.stringify(payload),
    muteHttpExceptions: true
  });
}

// Run this function once after filling BOT_TOKEN and WEB_APP_URL.
function setWebhook() {
  const WEB_APP_URL = "PASTE_YOUR_APPS_SCRIPT_EXEC_URL_HERE";
  const url = "https://api.telegram.org/bot" + BOT_TOKEN + "/setWebhook?url=" + encodeURIComponent(WEB_APP_URL);
  const r = UrlFetchApp.fetch(url);
  console.log(r.getContentText());
}
